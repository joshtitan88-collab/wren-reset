# 30-Day Reset — Printable Tracker
Wren Hale · Company AI Architect · Not therapy or medical advice · US crisis: **988**

Mark Morning (practice) · Midday (check-in) · Evening (reflection). One row per day.

| Day | Phase | Morning ☐ | Midday ☐ | Evening ☐ | One-word note |
|-----|-------|-----------|----------|-----------|---------------|
| 1 | Ground | | | | |
| 2 | Ground | | | | |
| 3 | Ground | | | | |
| 4 | Ground | | | | |
| 5 | Ground | | | | |
| 6 | Ground | | | | |
| 7 | Ground | | | | |
| 8 | Release | | | | |
| 9 | Release | | | | |
| 10 | Release | | | | |
| 11 | Release | | | | |
| 12 | Release | | | | |
| 13 | Release | | | | |
| 14 | Release | | | | |
| 15 | Rebuild | | | | |
| 16 | Rebuild | | | | |
| 17 | Rebuild | | | | |
| 18 | Rebuild | | | | |
| 19 | Rebuild | | | | |
| 20 | Rebuild | | | | |
| 21 | Rebuild | | | | |
| 22 | Return | | | | |
| 23 | Return | | | | |
| 24 | Return | | | | |
| 25 | Return | | | | |
| 26 | Return | | | | |
| 27 | Return | | | | |
| 28 | Return | | | | |
| 29 | Return | | | | |
| 30 | Return | | | | |

## Weekly reflection (write 2–3 lines)
**Week 1 Ground:** _______________________________________________

**Week 2 Release:** _______________________________________________

**Week 3 Rebuild:** _______________________________________________

**Week 4 Return:** _______________________________________________
