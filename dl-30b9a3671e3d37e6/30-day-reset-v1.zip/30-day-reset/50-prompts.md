# 50 Journaling Prompts — 30-Day Reset
**Wren Hale** · fictional AI wellness guide · Company AI Architect  
Not therapy or medical advice. If you are in crisis in the US, call or text **988**.

Tone: warm, direct, one sentence each. No clichés. No “dear diary.”

---

## Week 1 — Ground (1–12)
1. Name three things in the room you can touch without standing up.
2. What is the smallest unfinished task that is still taking mental space?
3. Where in your body do you notice tension right now, without trying to fix it?
4. What did you already do today that counted, even if it felt ordinary?
5. Write the hour of the day you feel most scattered, and what usually starts it.
6. Which notification can wait until after one quiet minute?
7. What does “enough for today” look like in one concrete action?
8. Who or what made the morning harder than it needed to be?
9. List five sounds you can hear from where you are sitting.
10. What boundary did you skip yesterday that you can keep for ten minutes today?
11. Which object on your table could become a start signal for a short pause?
12. Finish this line: Right now I feel ___, and that is information, not a verdict.

## Week 2 — Release (13–24)
13. What obligation are you carrying that nobody actually assigned to you?
14. Name one conversation you keep replaying, then write one sentence that ends the loop for now.
15. What are you pretending is urgent that is only loud?
16. Which expectation of yourself can you put down until next week?
17. Write the worry in one sentence, then write what is actually in your control today.
18. What would you stop explaining if you trusted your own no?
19. Which tab, app, or pile can you close without finishing it?
20. Who do you perform “fine” for, and what would honesty cost in one small way?
21. What old rule about rest no longer fits the life you have?
22. Name a resentment that is mostly tiredness wearing a costume.
23. What can you leave imperfect on purpose for twenty-four hours?
24. Finish this line: I release the idea that I must ___ before I am allowed to pause.

## Week 3 — Rebuild (25–37)
25. What four-minute practice would make tomorrow morning 10% kinder?
26. Which room in your home most needs one square of order, not a full reset?
27. Who is one person you can ask for a specific, small kind of help?
28. What time will you put the phone face-down tonight, and where will it live?
29. Write a one-line plan for the next hard Tuesday you already see coming.
30. Which habit almost works, and what tiny adjustment would make it finishable?
31. What food, water, or stretch does your afternoon self keep forgetting?
32. Name one skill you already have that you underuse when you are overwhelmed.
33. What does support look like this week in a calendar block, not a wish?
34. Which commitment can you renegotiate with one clear message?
35. What will you protect for yourself between 7 and 8 a.m. or p.m.?
36. Write three criteria for saying yes that you will actually use.
37. Finish this line: I am rebuilding a day that includes ___ on purpose.

## Week 4 — Return (38–50)
38. What practice from this month felt usable even on a bad day?
39. Which version of “back to normal” are you refusing, and why?
40. Who do you want to show up for without abandoning yourself?
41. What will you keep from the Reset when the novelty wears off?
42. Name one place you can return to in under two minutes when the day spikes.
43. What story about being behind can you retire with one true counter-fact?
44. How will you mark the end of a work block so your body knows it ended?
45. What kindness to yourself no longer needs to be earned?
46. Which relationship gets five honest minutes this week instead of another apology?
47. What does returning to yourself look like on a packed calendar day?
48. Write the one-sentence reminder you want on a sticky note by the kettle.
49. What will you celebrate as complete, even if nobody else notices?
50. Finish this line: I return to myself by ___, and I can start again tomorrow without drama.

---

*Product asset for the $27 30-Day Reset bundle. AI character disclosure applies to brand presence; prompts are tools, not treatment.*
