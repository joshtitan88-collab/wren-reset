# 30-Day Reset
## One simple practice per day for overwhelmed women

**Wren Hale** — fictional AI wellness guide  
**Company AI Architect** · companyaiarchitect.com

---

### Disclaimer (read first)
This guide offers emotional-regulation and daily-ritual practices for personal reflection. **It is not therapy, counseling, diagnosis, or medical advice.** It does not replace care from a licensed professional. No outcomes are promised.

If you are in crisis in the United States, call or text **988**. Outside the US, use local emergency or crisis resources.

Wren Hale is a **fictional AI-generated character**. Practices are tools, not lived experience of a real person.

---

## How to use this guide
1. Do **one day per day**. Missed a day? Continue with the next day. The plan waits.
2. Each day: a short **why**, a **practice**, a **journal prompt**, and a **note**.
3. Use the printable tracker (Morning / Midday / Evening).
4. Optional: use a prompt from the 50-prompt pack matching the week’s phase.
5. Finishable over impressive. Four quiet minutes beat a fantasy routine.

**Phases:** Days 1–7 Ground · 8–14 Release · 15–21 Rebuild · 22–30 Return

---

## Phase essays

### Ground
Grounding is not positivity. It is contact. You locate objects, sensations, and one honest sentence so the day stops being a smear.

### Release
Release is subtraction. You close tabs, end loops, and practice small nos. You are not required to forgive everything — only to stop carrying unpaid jobs for twenty-four hours at a time.

### Rebuild
Rebuild installs cues: kettle, phone parking, calendar blocks, shutdowns. Prefer location over willpower. Prefer small systems you will actually run.

### Return
Return means keeping what worked without drama. You are not behind. You start from here. You begin again tomorrow if needed.

---
## Day 1 — Name what is here
**Phase:** Ground

**Why**  
You cannot rearrange a day you have not named. Start by noticing, not fixing. Overwhelm often arrives as a fog. Naming cuts the fog into objects you can set down later.

**Practice**  
Sit somewhere ordinary. Set a timer for four minutes. Name five things you see, four you can touch, three you hear. When the timer ends, stand up. Do not add a second practice. That is the whole day.

**Journal prompt**  
What did you notice that you usually skip?

**Note**  
If your mind races, count the items on your fingers. The goal is contact with the present, not a perfect calm.

---
## Day 2 — One square of order
**Phase:** Ground

**Why**  
Overwhelm lives in piles. You do not need the whole room. You need one square you can finish. Finished squares teach your brain that completion is possible.

**Practice**  
Choose a surface the size of a notebook. Clear only that square. Put three things away. Stop when the square is clear — even if the rest of the room stays messy.

**Journal prompt**  
Which square will you protect tomorrow?

**Note**  
Photograph the square if it helps you remember that small finish lines count.

---
## Day 3 — Kettle as start signal
**Phase:** Ground

**Why**  
Rituals stick when they attach to something you already do. The kettle is enough of a ceremony.

**Practice**  
Fill the kettle. While it heats, put your phone face-down in another room. Drink the first sips standing still. No scrolling until the mug is half empty.

**Journal prompt**  
What will be your start signal this week?

**Note**  
No kettle? Use running water or a glass filled slowly. Same rule: pause until half done.

---
## Day 4 — Body scan without fixing
**Phase:** Ground

**Why**  
You do not need to solve the tension. You need to locate it. Location is the first kindness.

**Practice**  
Lie down or sit. Spend five minutes moving attention from feet to head. When you find tightness, breathe once into it. Stretch only if it feels easy and optional.

**Journal prompt**  
Where did you find the most noise in your body?

**Note**  
Skip any area that feels unsafe or too intense. Return to the breath and move on.

---
## Day 5 — One-sentence check-in
**Phase:** Ground

**Why**  
You do not need time to journal. You need one honest sentence before the day edits you.

**Practice**  
Before you open your phone, write: Right now I feel ___. Close the notebook. That is the practice.

**Journal prompt**  
What word showed up that surprised you?

**Note**  
Keep a dedicated page so the sentence does not get lost in to-do lists.

---
## Day 6 — Walk without a podcast
**Phase:** Ground

**Why**  
Your brain is already full. Add quiet, not more input. Quiet is a practice, not a luxury.

**Practice**  
Walk for ten minutes outdoors or around your home. No headphones. Count twenty breaths. If you lose count, start again without scolding yourself.

**Journal prompt**  
What did the quiet make louder?

**Note**  
If walking outside is hard today, walk the hallway twice. Distance is optional; attention is not.

---
## Day 7 — Weekly ground review
**Phase:** Ground

**Why**  
A week only counts if you look at it once. Review is how grounding becomes memory.

**Practice**  
Read days 1–6 notes for five minutes. Circle one practice you will repeat next week. Cross out one you will not force.

**Journal prompt**  
Which practice felt finishable on a hard day?

**Note**  
Finishable beats impressive. Keep the one you can do tired.

---
## Day 8 — Put down the unpaid job
**Phase:** Release

**Why**  
Some stress is borrowed. Name what you never agreed to carry.

**Practice**  
Write three tasks you are doing for approval, not necessity. Pause one of them for twenty-four hours. Tell nobody unless you must.

**Journal prompt**  
Which unpaid job can wait until Monday?

**Note**  
Unpaid jobs often look like being the family calendar, the office peacemaker, or the always-available friend.

---
## Day 9 — End the replay
**Phase:** Release

**Why**  
Replaying a conversation is unpaid overtime for your nervous system.

**Practice**  
Set a two-minute timer. Write the loop in three lines. Then write: For now, this ends here. Close the page. If it returns, reread the last line only.

**Journal prompt**  
What loop keeps stealing your evenings?

**Note**  
You are not required to resolve the story tonight. You are allowed to stop feeding it.

---
## Day 10 — Close three tabs
**Phase:** Release

**Why**  
Digital clutter is still clutter. Closing is a form of release that takes under a minute.

**Practice**  
Open your browser or phone home screen. Close or archive three things you are not touching today. Do not organize the rest.

**Journal prompt**  
What did you close that felt sticky?

**Note**  
Sticky often means unfinished emotion, not unfinished work. Note which.

---
## Day 11 — Say a small no
**Phase:** Release

**Why**  
A tiny no trains a larger one. Practice where the stakes are low.

**Practice**  
Choose one low-stakes request today. Decline in one clear sentence. No long apology. Notice the urge to over-explain, then stop.

**Journal prompt**  
Where did you want to soften the no?

**Note**  
Script: I cannot take that on this week. Thank you for understanding.

---
## Day 12 — Release the perfect morning
**Phase:** Release

**Why**  
The perfect morning is a trap. A usable morning is enough.

**Practice**  
Write your actual morning in five bullets. Star one bullet that is non-negotiable. Let the rest be flexible.

**Journal prompt**  
What fake standard can you retire?

**Note**  
If your morning already includes caring for others, your non-negotiable can be sixty silent seconds.

---
## Day 13 — Hand the worry a chair
**Phase:** Release

**Why**  
Worry wants the whole room. Give it a seat with a time limit.

**Practice**  
Set five minutes. Sit with the worry on purpose. Write it. When the timer ends, stand and do one ordinary task.

**Journal prompt**  
What ordinary task helped you leave the chair?

**Note**  
Ordinary tasks: wash a mug, fold two shirts, step outside once.

---
## Day 14 — Weekly release review
**Phase:** Release

**Why**  
Release is not drama. It is subtraction you can see.

**Practice**  
List everything you put down this week, even tiny. Keep one subtraction for next week. Celebrate quietly — not with a reward that creates work.

**Journal prompt**  
What subtraction made the most space?

**Note**  
If nothing felt big, count the small closes. They compound.

---
## Day 15 — Design a four-minute morning
**Phase:** Rebuild

**Why**  
You do not need a new life. You need four quiet minutes you can finish.

**Practice**  
Write a four-minute sequence you can do half-asleep: water, stretch, one sentence, start signal. Practice it once today.

**Journal prompt**  
What is step one of your four minutes?

**Note**  
Write the sequence on a card. Cards beat memory on hard mornings.

---
## Day 16 — Phone parking spot
**Phase:** Rebuild

**Why**  
Willpower fails. Location works. Make the default harder to break.

**Practice**  
Pick a physical parking spot for your phone during meals or the first hour after waking. Sticky note: Face down.

**Journal prompt**  
Where will the phone live when you need quiet?

**Note**  
If you need the phone for alarms, park it across the room, not under the pillow.

---
## Day 17 — Ask for one specific help
**Phase:** Rebuild

**Why**  
Vague help never arrives. Specific help sometimes does.

**Practice**  
Write one ask with a deadline and a clear yes/no. Send it to one person, or schedule to send tomorrow if today is full.

**Journal prompt**  
Who is safe enough for a specific ask?

**Note**  
Example: Can you take school pickup Thursday at 3? Yes or no is fine.

---
## Day 18 — Protect a block
**Phase:** Rebuild

**Why**  
An unprotected calendar fills with everyone else’s urgency.

**Practice**  
Block thirty minutes this week labeled with a real activity (walk, cook, sit). Treat it like a meeting you cannot casually cancel.

**Journal prompt**  
What did you put in the block?

**Note**  
If someone asks for that slot, offer a different time once. Then stop negotiating with yourself.

---
## Day 19 — Finishable habit tweak
**Phase:** Rebuild

**Why**  
Almost-habits die from being too big. Shrink until it is embarrassing how small it is.

**Practice**  
Take one habit that stalls. Cut it in half or attach it to an existing cue. Do the smaller version once.

**Journal prompt**  
What did you cut so it becomes finishable?

**Note**  
Two pushups beat a skipped workout. One sentence beats a blank journal.

---
## Day 20 — Evening shutdown cue
**Phase:** Rebuild

**Why**  
Your body needs an off switch that is not a scroll.

**Practice**  
Choose a five-minute shutdown: lights, kettle or tea, notebook sentence, phone plug-in away from bed. Run it once.

**Journal prompt**  
What will signal that the day ended?

**Note**  
Same cue every night trains the body faster than variety.

---
## Day 21 — Weekly rebuild review
**Phase:** Rebuild

**Why**  
Rebuilding is iteration, not reinvention. Change one notch, not the whole system.

**Practice**  
Rate your four-minute morning, phone parking, and shutdown from 1–5 for usability. Adjust the lowest score by one notch only.

**Journal prompt**  
Which system needs the smallest upgrade?

**Note**  
Small upgrades stick. Overhauls usually collapse by Wednesday.

---
## Day 22 — Return without catching up
**Phase:** Return

**Why**  
You are not behind. You are here. Catch-up fantasies keep you exhausted.

**Practice**  
Skip the catch-up fantasy. Do today’s practice only. Write: I start from here.

**Journal prompt**  
What catch-up story are you releasing?

**Note**  
Missed days are data, not debt. The plan waits.

---
## Day 23 — Two-minute reset place
**Phase:** Return

**Why**  
You need a place your nervous system recognizes when the day spikes.

**Practice**  
Choose a chair, corner, or walk loop. Go there for two minutes when stress rises. No fixing. Just arrive.

**Journal prompt**  
Where is your two-minute place?

**Note**  
Practice arriving once while calm so the path exists when you are not.

---
## Day 24 — Keep one, drop one
**Phase:** Return

**Why**  
Maintenance beats ambition after novelty fades.

**Practice**  
From the month, keep one practice. Formally drop one. Write both down so the decision is visible.

**Journal prompt**  
What are you keeping on purpose?

**Note**  
Dropping is a skill. Guilt is optional.

---
## Day 25 — Honest five minutes
**Phase:** Return

**Why**  
Connection without self-abandonment looks like timed honesty.

**Practice**  
Give someone five honest minutes of attention, or ask for five. No multitasking. End on time.

**Journal prompt**  
Who gets your honest five this week?

**Note**  
Ending on time is kindness to both people.

---
## Day 26 — Sticky-note reminder
**Phase:** Return

**Why**  
One line beats a manifesto you will not reread.

**Practice**  
Write one sentence for the kettle or mirror. Keep it under twelve words. Change it only after seven days.

**Journal prompt**  
What sentence belongs by the kettle?

**Note**  
Example: Four minutes. Then the day.

---
## Day 27 — Packed-day protocol
**Phase:** Return

**Why**  
Busy days need a smaller plan, not no plan.

**Practice**  
Write a three-item packed-day plan: water, one sentence, two-minute place. Use it on the next overloaded day.

**Journal prompt**  
What three items stay when everything else flexes?

**Note**  
If you only do one, do the two-minute place. Then rebuild.

---
## Day 28 — Mark completion
**Phase:** Return

**Why**  
Unmarked completion keeps the nervous system working overtime.

**Practice**  
At day’s end, write three things that are done. Say them aloud once. Stop adding more.

**Journal prompt**  
What completions do you usually leave invisible?

**Note**  
Include tiny completions: answered the email, fed yourself, showed up.

---
## Day 29 — Soft celebration
**Phase:** Return

**Why**  
Celebration does not need an audience or a purchase.

**Practice**  
Choose a quiet marker for finishing the month: a walk, a clean mug, a song. Do it without posting.

**Journal prompt**  
How will you mark day 30 quietly?

**Note**  
Visibility is optional. Completion is the point.

---
## Day 30 — Begin again without drama
**Phase:** Return

**Why**  
The plan waits. It does not scold. That is the whole lesson.

**Practice**  
Reread your week-4 notes. Schedule the next seven days of the four-minute morning only. If you miss a day, do the next one — once is enough.

**Journal prompt**  
What will you practice on day 31?

**Note**  
You already know how to return. Practice returning.

---
## After day 30
Continue the finishable pieces:
1. Four-minute morning  
2. Phone parking spot  
3. One-sentence check-in  
4. Sunday five-minute review  

When life spikes, use Day 23 (two-minute place) before inventing a new system.

---

## Disclaimer page
**30-Day Reset** · Wren Hale / Company AI Architect  
Not therapy or medical advice · No guaranteed results · Fictional AI character  
US crisis: **988** · Support (not clinical): outreach@companyaiarchitect.com  
https://companyaiarchitect.com  

© Company AI Architect. Personal use by purchaser.


## Materials & setup
Notebook or notes app. Timer. Pen. Optional sticky notes. Optional printed tracker. A chair or walk loop for your two-minute place (Day 23).

## Voice of this guide
Warm. Exact. A little dry. Short sentences. You — not we. No exclamation marks. Exact numbers when possible.

## Missed days
Skip the guilt speech. Do the next day's practice once. Optional: repeat yesterday as a bonus — never as punishment.

## If today is hard (quick reference)
- Day 1: If today is hard: name three things only.
- Day 2: If today is hard: clear three objects, not a square.
- Day 3: If today is hard: one full mug without the phone.
- Day 4: If today is hard: three breaths into the tightest spot.
- Day 5: If today is hard: one word instead of a sentence.
- Day 6: If today is hard: two minutes of hallway walking.
- Day 7: If today is hard: circle one practice without rereading all notes.
- Day 8: If today is hard: pause one unpaid task for tonight only.
- Day 9: If today is hard: write one line of the loop, then stop.
- Day 10: If today is hard: close one tab.
- Day 11: If today is hard: decline by text with one sentence.
- Day 12: If today is hard: star one morning bullet only.
- Day 13: If today is hard: two minutes with the worry, then wash a mug.
- Day 14: If today is hard: list two subtractions, not a full review.
- Day 15: If today is hard: design two minutes, not four.
- Day 16: If today is hard: park the phone for one meal.
- Day 17: If today is hard: write the ask without sending yet.
- Day 18: If today is hard: protect fifteen minutes.
- Day 19: If today is hard: cut the habit to something you can finish in sixty seconds.
- Day 20: If today is hard: plug the phone in away from bed — that is enough.
- Day 21: If today is hard: rate one system only.
- Day 22: If today is hard: write I start from here and stop.
- Day 23: If today is hard: go to the place for sixty seconds.
- Day 24: If today is hard: keep one practice; defer the drop decision.
- Day 25: If today is hard: three honest minutes.
- Day 26: If today is hard: six words on a sticky note.
- Day 27: If today is hard: water + two-minute place.
- Day 28: If today is hard: name one completion aloud.
- Day 29: If today is hard: one song, no post.
- Day 30: If today is hard: schedule three mornings, not seven.

## Weekly reflection templates
**Week 1 Ground:** Which practice felt finishable when you were tired?

**Week 2 Release:** What did you put down that you thought you had to carry?

**Week 3 Rebuild:** Which cue needs one small upgrade?

**Week 4 Return:** What will you keep for the next thirty days — one thing only?

## Common stalls
Perfectionism → shrink. Shame after a miss → next day only. Overbuilding → keep one system. Advice-collecting → run the four minutes.
